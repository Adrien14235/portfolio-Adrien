package vue;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.HashMap;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import controleur.ConvertCSV;
import controleur.StatEtab;
import model.Etablissement;

public class FenetrePrincipale extends JFrame {
    private static final long serialVersionUID = 1L;
    private static String csvFileName = "ecoles-creches-idf.csv";

    public FenetrePrincipale() {
        super();
        build();
    }

    private void build() {
        ConvertCSV.chargerEtablissements("C:/Projet/respirestatetug03/" + csvFileName);

        setTitle("RespireStat");
        setSize(960, 820);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(buildContentPaneHomePage());
    }

    private JPanel buildContentPaneHomePage() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());

        JTabbedPane onglets = new JTabbedPane(SwingConstants.TOP);
        onglets.setPreferredSize(new Dimension(900, 780));

        JPanel onglet1 = new JPanel();
        JLabel label;
        label = new JLabel();
        label.setText("<html><body><p style='text-align:center'>Ouverture du fichier " + csvFileName
                + "<br>Bienvenue sur l'application RespireStat<br /><br />Cliquez sur un des onglets pour accéder aux statistiques</p></body></html>");
        onglet1.add(label);
        onglets.addTab("Accueil", onglet1);

        JPanel onglet2 = new JPanel();
        JLabel labelTableau = new JLabel();
        Etablissement etabNO2, etabPM10, etabPM25;
        JTable table;
        JScrollPane spane;
        TableauStat1 tab1;

        onglet2.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridy = 0;
        for (int annee = 2012; annee <= 2017; annee++) {
            labelTableau.setText(" " + annee);
            etabNO2 = StatEtab.getPlusPolluantNO2(ConvertCSV.listeEtab, annee);
            etabPM10 = StatEtab.getPlusPolluantPM10(ConvertCSV.listeEtab, annee);
            etabPM25 = StatEtab.getPlusPolluantPM25(ConvertCSV.listeEtab, annee);

            if (etabNO2 != null && etabPM10 != null && etabPM25 != null) {
                Etablissement[] etabs = new Etablissement[3];
                etabs[0] = etabNO2;
                etabs[1] = etabPM10;
                etabs[2] = etabPM25;
                tab1 = new TableauStat1(etabs, annee);

                table = new JTable(tab1);
                spane = new JScrollPane(table);
                table.setCellSelectionEnabled(false);
                table.setPreferredSize(new Dimension(500, 96));
                table.setPreferredScrollableViewportSize(table.getPreferredSize());
                table.setFillsViewportHeight(true);
                onglet2.add(spane, c);
                c.gridy++;
            }
        }
        onglets.addTab("Les plus pollués", onglet2);

        JPanel onglet3 = new JPanel();
        HashMap<String, Double> moyenneVillesNO2 = new HashMap<String, Double>();
        HashMap<String, Double> moyenneVillesPM10 = new HashMap<String, Double>();
        HashMap<String, Double> moyenneVillesPM25 = new HashMap<String, Double>();
        for (String ville : ConvertCSV.listeVilles) {
            moyenneVillesNO2.put(ville, StatEtab.getMoyennePolluantNO2Ville(ConvertCSV.listeEtab, ville, 2017));
            moyenneVillesPM10.put(ville, StatEtab.getMoyennePolluantPM10Ville(ConvertCSV.listeEtab, ville, 2017));
            moyenneVillesPM25.put(ville, StatEtab.getMoyennePolluantPM25Ville(ConvertCSV.listeEtab, ville, 2017));
        }
        TableauStat2 tab2 = new TableauStat2(moyenneVillesNO2, moyenneVillesPM10, moyenneVillesPM25);
        table = new JTable(tab2);
        spane = new JScrollPane(table);
        onglet3.add(spane);
        onglets.addTab("Moyenne par ville 2017", onglet3);

        JPanel onglet4 = new JPanel();
        HashMap<String, Double> moyenneDepartementsNO2 = new HashMap<String, Double>();
        HashMap<String, Double> moyenneDepartementsPM10 = new HashMap<String, Double>();
        HashMap<String, Double> moyenneDepartementsPM25 = new HashMap<String, Double>();
        for (String departement : ConvertCSV.listeDepartements) {
            moyenneDepartementsNO2.put(departement,
                    StatEtab.getMoyennePolluantNO2Dpt(ConvertCSV.listeEtab, departement, 2017));
            moyenneDepartementsPM10.put(departement,
                    StatEtab.getMoyennePolluantPM10Dpt(ConvertCSV.listeEtab, departement, 2017));
            moyenneDepartementsPM25.put(departement,
                    StatEtab.getMoyennePolluantPM25Dpt(ConvertCSV.listeEtab, departement, 2017));
        }
        TableauStat3 tab3 = new TableauStat3(moyenneDepartementsNO2, moyenneDepartementsPM10, moyenneDepartementsPM25);
        table = new JTable(tab3);
        spane = new JScrollPane(table);
        onglet4.add(spane);
        onglets.addTab("Moyenne par departements 2017", onglet4);

        JPanel onglet5 = new JPanel();
        HashMap<String, Double> evolutionDepartementsNO2 = new HashMap<>();
        HashMap<String, Double> evolutionDepartementsPM10 = new HashMap<>();
        HashMap<String, Double> evolutionDepartementsPM25 = new HashMap<>();
        for (String departement : ConvertCSV.listeDepartements) {
            evolutionDepartementsNO2.put(departement, calculateEvolutionNO2(departement, 2017, 2016));
            evolutionDepartementsPM10.put(departement, calculateEvolutionPM25(departement, 2017, 2016));
            evolutionDepartementsPM25.put(departement, calculateEvolutionPM10(departement, 2017, 2016));
        }
        TableauStat4 tab4 = new TableauStat4(evolutionDepartementsNO2, evolutionDepartementsPM10, evolutionDepartementsPM25);
        table = new JTable(tab4);
        spane = new JScrollPane(table);
        onglet5.add(spane);
        onglets.addTab("Pourcentage de 2012 à 2017", onglet5);

        panel.add(onglets);
        return panel;
    }
		//calcule via taux d'évolution 
    private Double calculateEvolutionNO2(String departement, int annee, int anneePrecedente) {
        double prev = StatEtab.getMoyennePolluantNO2Dpt(ConvertCSV.listeEtab, departement, anneePrecedente);
        double curr = StatEtab.getMoyennePolluantNO2Dpt(ConvertCSV.listeEtab, departement, annee);
        double pourcentageEvolution = 100 * (curr - prev) / prev;
        return pourcentageEvolution;
    }

    private Double calculateEvolutionPM25(String departement, int annee, int anneePrecedente) {
        double prev = StatEtab.getMoyennePolluantPM25Dpt(ConvertCSV.listeEtab, departement, anneePrecedente);
        double curr = StatEtab.getMoyennePolluantPM25Dpt(ConvertCSV.listeEtab, departement, annee);
        double pourcentageEvolution = 100 * (curr - prev) / prev;
        return pourcentageEvolution;
    }

    private Double calculateEvolutionPM10(String departement, int annee, int anneePrecedente) {
        double prev = StatEtab.getMoyennePolluantPM10Dpt(ConvertCSV.listeEtab, departement, anneePrecedente);
        double curr = StatEtab.getMoyennePolluantPM10Dpt(ConvertCSV.listeEtab, departement, annee);
        double pourcentageEvolution = 100 * (curr - prev) / prev;
        return pourcentageEvolution;
    }

    public static void main(String[] args) {
        new FenetrePrincipale().setVisible(true);
    }
}
