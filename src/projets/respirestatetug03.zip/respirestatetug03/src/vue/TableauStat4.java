package vue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.swing.table.AbstractTableModel;

public class TableauStat4 extends AbstractTableModel {
    private static final long serialVersionUID = 1L;

    private final String[] entetes = { "Année", "Départements", "NO2", "PM10", "PM25" };
    private final HashMap<String, HashMap<String, HashMap<String, Double>>> pourcentagesEvolution;

    public TableauStat4(HashMap<String, Double> evolutionDepartementsNO2,
                    HashMap<String, Double> evolutionDepartementsPM10,
                    HashMap<String, Double> evolutionDepartementsPM25) {
        pourcentagesEvolution = new HashMap<>();

        for (String departement : evolutionDepartementsNO2.keySet()) {
            HashMap<String, HashMap<String, Double>> annees = new HashMap<>();

            // Parcourir les années de 2012 à 2017
            for (int annee = 2012; annee <= 2017; annee++) {
                HashMap<String, Double> pourcentages = new HashMap<>();

                // Remplir les valeurs pour chaque polluant pour l'année donnée
                pourcentages.put("NO2", getValeur(evolutionDepartementsNO2, departement, annee));
                pourcentages.put("PM10", getValeur(evolutionDepartementsPM10, departement, annee));
                pourcentages.put("PM25", getValeur(evolutionDepartementsPM25, departement, annee));

                annees.put(String.valueOf(annee), pourcentages);
            }

            // Ajouter les valeurs pour le département actuel
            pourcentagesEvolution.put(departement, annees);
        }
    }

    @Override
    public int getColumnCount() {
        return entetes.length;
    }

    @Override
    public String getColumnName(int columnIndex) {
        return entetes[columnIndex];
    }

    @Override
    public int getRowCount() {
        // Nombre de lignes est le nombre total de départements * nombre d'années
        return pourcentagesEvolution.size() * 6; // 6 années (2012 à 2017)
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Set<String> departements = pourcentagesEvolution.keySet();
        List<String> departementsList = new ArrayList<>(departements);
        String departement = departementsList.get(rowIndex / 6); // 6 lignes par département

        HashMap<String, HashMap<String, Double>> annees = pourcentagesEvolution.get(departement);
        List<String> anneesList = new ArrayList<>(annees.keySet());
        String annee = anneesList.get(rowIndex % 6); // 6 lignes par année

        HashMap<String, Double> pourcentages = annees.get(annee);

        switch (columnIndex) {
            case 0:
                return annee;
            case 1:
                return departement;
            case 2:
                // Pourcentage d'évolution pour NO2
                return pourcentages.get("NO2");
            case 3:
                // Pourcentage d'évolution pour PM10
                return pourcentages.get("PM10");
            case 4:
                // Pourcentage d'évolution pour PM25
                return pourcentages.get("PM25");
            default:
                throw new IllegalArgumentException("Index de colonne invalide");
        }
    }

    private Double getValeur(HashMap<String, Double> evolution, String departement, int annee) {
        // Récupérer la valeur pour l'année donnée, ou retourner 0 si non trouvée
        return evolution.containsKey(departement) ? evolution.get(departement) : 0.0;
    }
}
