package vue;

import java.util.HashMap;

import javax.swing.table.AbstractTableModel;

import controleur.ConvertCSV;

public class TableauStat3 extends AbstractTableModel{
	private static final long serialVersionUID = 1L;

	private final String[] entetes = { "Departements", "NO2", "PM10", "PM25"};
	private final HashMap<String, Double> moyenneDepartementsNO2;
	private final HashMap<String, Double> moyenneDepartementsPM10;
	private final HashMap<String, Double> moyenneDepartementsPM25;
	

	public TableauStat3(HashMap<String, Double> moyenneDepartementsNO2, HashMap<String, Double> moyenneDepartementsPM10, HashMap<String, Double> moyenneDepartementsPM25) {
		this.moyenneDepartementsNO2 = moyenneDepartementsNO2;
		this.moyenneDepartementsPM10 = moyenneDepartementsPM10;
		this.moyenneDepartementsPM25 = moyenneDepartementsPM25;
	}
	
	@Override
	public int getColumnCount() {

		return entetes.length;
	}
	@Override
	public String getColumnName(int columnIndex) {
		return entetes[columnIndex];
	}

	@Override
	public int getRowCount() {
		return ConvertCSV.listeDepartements.size();
	}
	

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case 0:
			return ConvertCSV.listeDepartements.get(rowIndex);
		case 1:
			return this.moyenneDepartementsNO2.get(ConvertCSV.listeDepartements.get(rowIndex));

		case 2:
			return this.moyenneDepartementsPM10.get(ConvertCSV.listeDepartements.get(rowIndex));

		case 3:
			return this.moyenneDepartementsPM25.get(ConvertCSV.listeDepartements.get(rowIndex));

		default:
			throw new IllegalArgumentException();
			
		}
	}
}


