package model;

public class CoordGPS {
	private double latitude;
	private double longitude;
	private Object coordonnees;
	
	public CoordGPS(String geometry) {
		this(getLatitudeFromGeometry(geometry),getLongitudeFromGeometry(geometry));
	}
	public CoordGPS(double lat, double lon) {
		latitude = lon;
		longitude = lat;
	}
	private static String[] extractLatLongFromGeometry(String geometry) {
		String extract = geometry.substring(2, geometry.length()-1);
		String[] coord = extract.split(", ");
		return coord;
	}
	private static double getLatitudeFromGeometry(String geometry) {
		return Double.parseDouble(extractLatLongFromGeometry(geometry)[0]);
	}
	private static double getLongitudeFromGeometry(String geometry) {
		return Double.parseDouble(extractLatLongFromGeometry(geometry)[1]);
	}
	public double getLatitude() {
		return latitude;
	}
	public double getLongitude() {
		return longitude;
	}
	@Override
	public String toString() {
		return "CoordGPS [latitude=" + latitude + ", longitude=" + longitude + "]";
	}

	public double distanceVersParis(CoordGPS coord) {
		final double parisLatitude = 48.8566;
        final double parisLongitude = 2.3522;
        double earthRadius = 6371; // Rayon moyen de la Terre en kilomètres
        double lat1 = Math.toRadians(((CoordGPS) this.coordonnees).getLatitude());
        double lon1 = Math.toRadians(((CoordGPS) this.coordonnees).getLongitude());
        double lat2 = Math.toRadians(parisLatitude);
        double lon2 = Math.toRadians(parisLongitude);

        double dLat = lat2 - lat1;
        double dLon = lon2 - lon1;

        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(lat1) * Math.cos(lat2)
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = earthRadius * c;

        return distance;
    }
}

	
